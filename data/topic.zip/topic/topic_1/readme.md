trong folder có 3 file :

description : mô tả topic

fill : các câu hỏi điền từ
	cứ hai dòng là một câu hỏi.
	dòng trên : câu hỏi
	dòng dưới : đáp án
	NOte : đáp án là mảng. split("$") giá trị dòng để thu được các phần tử mảng

option : các câu hỏi lựa chọn
	cứ ba dòng là một câu hỏi
	dòng một : câu hỏi 
	dòng hai : đáp án. Các đáp án cách nhau dấu '$'. split('$') để thu được mảng
	dòng ba : index của đáp án. (start from 0 )
